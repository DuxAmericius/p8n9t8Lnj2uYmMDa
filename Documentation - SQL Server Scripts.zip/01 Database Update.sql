/* 01 Database Update.java
   =============================================================================
                         Josh Talley and Daniel O'Donnell
                                Dulaney High School
                      Mobile Application Development 2016-17
   =============================================================================
   Purpose: The SchoolDistance table got very large, so it was necessary toid
   modify the default Easy Table column size from nvarchar2(450) to nvarchar2(12).
   
   Also, searching was very slow until indexes were created that match each where
   clause used by the application.
*/
-- Modify the SchoolDistance table so it doesn't get too large
ALTER TABLE SchoolDistance
ALTER COLUMN fromid nvarchar(12) not null;
ALTER TABLE SchoolDistance
ALTER COLUMN toid nvarchar(12) not null;

-- Create indexes that match the where clause of each search
CREATE INDEX searchDistance ON SchoolDistance (fromid, miles, deleted);
CREATE INDEX searchAccount ON Account (schoolid, deleted);
CREATE INDEX searchItem ON SaleItem (userid, deleted);
CREATE INDEX searchZip ON ZipCodes (stateText, city, deleted);
CREATE INDEX searchSchool ON ZipCodes (zip, deleted);

