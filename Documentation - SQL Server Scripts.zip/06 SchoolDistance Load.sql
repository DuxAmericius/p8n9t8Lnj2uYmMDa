/* 06 SchoolDistance Load.java
   =============================================================================
                         Josh Talley and Daniel O'Donnell
                                Dulaney High School
                      Mobile Application Development 2016-17
   =============================================================================
   Purpose: Pre-populate the SchoolDistance table so that it has the distance
   between ever school within a 10-mile radius. This creates a huge amount of 
   data, but makes searching very fast. Because it takes so long to load, the
   statement has to be executed in batches. So we ran it for each state, except
   for the states with the fewest schools, which were combined in the same run.
   
   For each stateText condition that was uncommented, the statement would take
   anywhere from 8 to 30 minutes to complete. New York had the most rows, 
   followed by California.
*/
INSERT INTO SchoolDistance (fromid, toid, miles)
SELECT f.id, t.id
     , 2 * 3961 * asin(sqrt(
	    square(sin(radians((t.lat - f.lat) / 2))) +
	    cos(radians(f.lat)) * cos(radians(t.lat)) *
	    square(sin(radians((t.long - f.long) / 2)))
	   )) miles
FROM Schools f
INNER JOIN Schools t ON (t.id <> f.id AND t.lat <> 0 AND t.long <> 0)
WHERE 2 * 3961 * asin(sqrt(
	    square(sin(radians((t.lat - f.lat) / 2))) +
	    cos(radians(f.lat)) * cos(radians(t.lat)) *
	    square(sin(radians((t.long - f.long) / 2)))
	   )) <= 10
--AND f.stateText in ('Nevada','Hawaii','Wyoming','Rhode Island','Deleware','Dist. of Columbia','Virgin Islands');
--AND f.stateText in ('New Hampshire', 'Vermont');
--AND f.stateText in ('North Dakota','South Dakota');
--AND f.stateText = 'Montana';
--AND f.stateText = 'West Virginia';
--AND f.stateText = 'Idaho';
--AND f.stateText = 'Maine';
--AND f.stateText = 'New Mexico';
--AND f.stateText = 'Alaska';
--AND f.stateText = 'Nebraska';
--AND f.stateText = 'Utah';
--AND f.stateText = 'Iowa';
--AND f.stateText = 'Kansas';
--AND f.stateText = 'Puerto Rico';
--AND f.stateText = 'Maryland';
--AND f.stateText = 'Virginia';
--AND f.stateText = 'Oregon';
--AND f.stateText = 'Arkansas';
--AND f.stateText = 'South Carolina';
--AND f.stateText = 'Mississippi';
--AND f.stateText = 'Kentucky';
--AND f.stateText = 'Louisiana';
--AND f.stateText = 'Colorado';
--AND f.stateText = 'Oklahoma';
--AND f.stateText = 'Indiana';
--AND f.stateText = 'Alabama';
--AND f.stateText = 'Minnesota';
--AND f.stateText = 'Massachusetts';
--AND f.stateText = 'Washington';
--AND f.stateText = 'Wisconsin';
--AND f.stateText = 'Tennessee';
--AND f.stateText = 'New Jersey';
--AND f.stateText = 'Georgia';
--AND f.stateText = 'Missouri';
--AND f.stateText = 'Connecticut';
--AND f.stateText = 'Arizona';
--AND f.stateText = 'North Carolina';
--AND f.stateText = 'Illinois';
--AND f.stateText = 'Ohio';
--AND f.stateText = 'Pennsylvania';
--AND f.stateText = 'Michigan';
--AND f.stateText = 'Florida';
--AND f.stateText = 'New York';
--AND f.stateText = 'Texas';
--AND f.stateText = 'Alabama';
--AND f.stateText = 'Guam';
--AND f.stateText = 'California';

