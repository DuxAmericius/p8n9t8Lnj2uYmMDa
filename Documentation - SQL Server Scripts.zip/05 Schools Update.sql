/* 05 Schools Update.java
   =============================================================================
                         Josh Talley and Daniel O'Donnell
                                Dulaney High School
                      Mobile Application Development 2016-17
   =============================================================================
   Purpose: Update the City and State for each school to use the primary value
   from the Zip Codes table.
*/
UPDATE s
SET    s.city = substring(z.locationText, 1, len(z.city)), s.stateText = z.stateText
FROM   Schools s
INNER JOIN ZipCodes z ON z.zip = s.zip AND z.locationType = 'PRIMARY'
WHERE s.city IS NULL;
